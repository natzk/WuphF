package com.example.wuphf

data class FavoriteItem(
    val name: String,
    val number: String,
    val imageUri: String?)